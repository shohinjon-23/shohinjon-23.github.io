// Минимальный service worker: нужен, чтобы приложение можно было установить.
// Кэш не используется, поэтому обновления страницы приходят сразу.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});
